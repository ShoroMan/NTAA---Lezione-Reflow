﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TestInteraction : MonoBehaviour
{
    Rigidbody myRB;
    // Start is called before the first frame update
    void Start()
    {
        if (InputManager.Singleton != null)
        {
            InputManager.Singleton.RightHand_GrabGripDown.AddListener(GrabBehaviour);
        }
        else
        {
            Debug.LogWarning("Input Manager Not Found!!");
        }
        myRB = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void GrabBehaviour()
    {
        if (InputManager.Singleton.GrabbableOnRightHand == transform)
        {
            print("Grabbed");
            myRB.isKinematic = true;
            transform.parent = InputManager.Singleton.RightHandTransform;
        }
    }
}
