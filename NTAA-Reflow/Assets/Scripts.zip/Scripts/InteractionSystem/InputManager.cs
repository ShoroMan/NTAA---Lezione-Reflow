﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Valve.VR;
using Valve.VR.InteractionSystem;
using UnityEngine.Events;

public class InputManager : MonoBehaviour
{
    public static InputManager Singleton;

    public SteamVR_Action_Boolean GrabGripAction = SteamVR_Input.GetAction<SteamVR_Action_Boolean>("GrabGrip");

    [HideInInspector]
    public bool RightHand_Grab;
    [HideInInspector]
    public bool LeftHand_Grab;
    [Header("Hands")]
    public Transform RightHandTransform;
    public Transform LeftHandTransform;


    [Header("Input Events")]
    public UnityEvent RightHand_GrabGripDown;
    public UnityEvent RightHand_GrabGripUp;
    [Space(10)]
    public UnityEvent LeftHand_GrabGripDown;
    public UnityEvent LeftHand_GrabGripUp;

    [Header("Grabbable Objects References")]
    public Transform GrabbableOnLeftHand;
    public Transform GrabbableOnRightHand;

    private void OnEnable()
    {
        Singleton = this;
    }



    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        RightHandInputHandler();
        LeftHandInputHandler();
    }

    void RightHandInputHandler()
    {
        RightHand_Grab = GrabGripAction != null && GrabGripAction.GetState(SteamVR_Input_Sources.RightHand);
        if (GrabGripAction != null && GrabGripAction.GetStateDown(SteamVR_Input_Sources.RightHand)) RightHand_GrabGripDown.Invoke();
        if (GrabGripAction != null && GrabGripAction.GetStateUp(SteamVR_Input_Sources.RightHand)) RightHand_GrabGripUp.Invoke();
    }

    void LeftHandInputHandler()
    {
        LeftHand_Grab = GrabGripAction != null && GrabGripAction.GetState(SteamVR_Input_Sources.LeftHand);
        if (GrabGripAction != null && GrabGripAction.GetStateDown(SteamVR_Input_Sources.LeftHand)) LeftHand_GrabGripDown.Invoke();
        if (GrabGripAction != null && GrabGripAction.GetStateUp(SteamVR_Input_Sources.LeftHand)) LeftHand_GrabGripUp.Invoke();
    }
}
