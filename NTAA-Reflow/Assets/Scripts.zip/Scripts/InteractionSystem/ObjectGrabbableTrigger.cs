﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjectGrabbableTrigger : MonoBehaviour
{
    public bool IsRightHand;
    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Grabbable")
        {
            if (IsRightHand)
                InputManager.Singleton.GrabbableOnRightHand = other.transform;
            else
                InputManager.Singleton.GrabbableOnLeftHand = other.transform;
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.gameObject.tag == "Grabbable")
        {
            if (IsRightHand)
                InputManager.Singleton.GrabbableOnRightHand = null;
            else
                InputManager.Singleton.GrabbableOnLeftHand = null;
        }
    }
}
